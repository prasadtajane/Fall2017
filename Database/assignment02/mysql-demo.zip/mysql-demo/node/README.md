# To Debug

1. `npm install`
1. `npm run dev`

# To run

1. `npm install --production`
1. `npm start`
