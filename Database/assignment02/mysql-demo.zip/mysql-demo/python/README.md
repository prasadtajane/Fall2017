# To Install

`conda install pymysql`

# To Run

`python chinook.py`
